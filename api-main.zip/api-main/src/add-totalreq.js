import Web from "../models/website.js";

async function addReq(req, res, next) {
    try {
        await Web.updateOne({}, {
            $inc: {
                TodayReq: 1
            }
        })
        let data = await Web.findOne();
        if (!data) {
            data = new Web();
        }

        data.TotalReq++;

        await data.save();

    } catch (error) {
        console.error('Error updating TotalReq:', error);
        return res.status(500).json({ error: 'Internal Server Error' });
    }

    next();
}

export { addReq };

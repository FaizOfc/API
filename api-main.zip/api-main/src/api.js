import { fetch } from "../lib/fetch.js"

export async function getApikey() {
    try {
        const res = await fetch('http://15.235.142.199/api/freeApikey')
        return res.apikey
    } catch (e) {
        console.log(e)
    }
}
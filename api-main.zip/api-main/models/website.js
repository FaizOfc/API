import mongoose from 'mongoose';

const webSchema = new mongoose.Schema({
    TotalReq: {
        type: Number,
        default: 0
    },
    TotalUsr: {
        type: Number,
        default: 0
    },
    Visitor: {
        type: Number,
        default: 0
    },
    TodayReq: {
        type: Number,
    },
    LastUpdated: {
        type: Date,
        default: Date.now
    }
});

const Web = mongoose.model('Web', webSchema);

export default Web;

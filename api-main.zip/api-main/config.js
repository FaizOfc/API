
global.creator = "Pais Rest Apu";
global.url = {
    mongodb: 'mongodb+srv://xyzen:cdn@cdn.uhmuyf9.mongodb.net/olxyz',
    host: 'https://api.xyzen.tech'
}

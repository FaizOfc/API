import express from 'express';
import numeral from 'numeral';
import fs from "fs";
import Web from "../models/website.js"

const router = express.Router()


router.get('/pages/downloader', async(req, res) => {
    const rowsData = JSON.parse(fs.readFileSync('src/db/list/list-downloader.json'))
    res.render('./pages/api/downloader', {
        rowsData
    })
})

router.get('/pages/generate', async(req, res) => {
    const rowsData = JSON.parse(fs.readFileSync('src/db/list/list-generate.json'))
    res.render('./pages/api/generate', {
        rowsData
    })
})
router.get('/pages/pricing', async(req, res) => {
    res.render('./pages/pricing', {

    })
})

router.get('/pages/dashboard', async(req, res) => {
    let visitorData = await Web.findOne();

    res.render('./pages/dashboard', {
        visitor: visitorData.Visitor,
        users: 1,
        totalreq: visitorData.TotalReq,
        todayreq: visitorData.TodayReq
    })
})


router.get('/', async (req, res) => {
    let visitorData = await Web.findOne();
    if (!visitorData) {
        visitorData = new Web();
    }

    visitorData.Visitor++;

    await visitorData.save();
    
    const totalvid = visitorData.Visitor > 1000 ? numeral(visitorData.Visitor).format('0.0a') : visitorData.Visitor;
    const totalreq = visitorData.TotalReq > 1000 ? numeral(visitorData.TotalReq).format('0.0a') : visitorData.TotalReq;
    const reqtoday = visitorData.TodayReq > 1000 ? numeral(visitorData.TodayReq).format('0.0a') : visitorData.TodayReq;

    res.render('./pages/landing', { 
        data: [
            { total: totalreq, name: 'Requests' },
            { total: 1, name: 'Users' },
            { total: '647', name: 'Features' },
            { total: totalvid, name: 'Visitors' }
        ]
    })
})


export default router
import { Router } from "express"; 
import tools from "./api/tools.js";
import game from "./api/game.js";
import downloader from "./api/download.js";
import generate from "./api/generate.js";
import islami from "./api/islami.js"
import pages from "./pages.js";
import auth from "./auth.js";
import anime from "./api/anime.js";
import image from "./api/image.js";


const router = Router();

router.use(image);
router.use(anime);
router.use(auth);
router.use(islami);
router.use(generate);
router.use(downloader);
router.use(game);
router.use(pages);
router.use(tools);


router.use(function(err, req, res, next) {
    res.status(404 || 500);
    res.render('./pages/error');
})
export default router

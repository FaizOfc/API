import express from 'express';
import jwt from 'jsonwebtoken';

const router = express.Router()

router.get('/auth/login', async(req, res) => {
    res.render('./pages/auth/login')
})
router.get('/auth/register', async(req, res) => {
    res.render('./pages/auth/register')
})
router.get('/auth/forgetpassword', async(req, res) => {
    res.render('./pages/auth/forgetpassword')
})


export default router
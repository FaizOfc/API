import { Router } from "express";
import axios from "axios";
import { getApikey } from "../../src/api.js";
import { addReq } from "../../src/add-totalreq.js"
import { downloadImage, generateRandomUUID } from "../../lib/fetch.js";
import { remini } from "../../scapers/remini.js";

const router = Router();

router.get('/api/generate/bingimg', addReq, async (req, res) => {
    const q = req.query.q;

    const api = await getApikey();
    const { data } = await axios.get(`http://15.235.142.199/api/ai/bingAi?prompt=${q}&apikey=${api}`)
    const a = await generateRandomUUID('.jpg')
    await downloadImage(data.image[0], `public/file/${a}`)
    res.json({ creator, status: true, result: url.host + `/assets/file/${a}` })
})

router.get('/api/generate/upscale', async(req, res) => {
    const url = req.query.url;

    if (!url) return res.json({ creator, status: false, message: 'Required Url'})
    const remi = await remini(url)
    const a = await generateRandomUUID('.png');
    await downloadImage(remi, `public/file/${a}`);
    res.json({ creator, status: true, result : `https://api.olxyz.my.id/assest/file/${a}`})
    
})
router.get('/api/generate/qc', addReq, async (req, res) => {
    const avatar = req.query.avatar;
    const name = req.query.name;
    const text = req.query.text;
    const media = req.query.media;

    if (!avatar || !name || !text) return res.json({ creator, status: false, message: 'Require Avatar & Nickanme & Text & Media ( Opsional )'})

    if (!media) {
        var data = {
            "type": "quote",
            "format": "png",
            "backgroundColor": "#FFFFFF",
            "width": 512,
            "height": 768,
            "scale": 2,
            "messages": [{
                "entities": [],
                "avatar": true,
                "from": {
                    "id": 1,
                    "name": name,
                    "photo": {
                        "url": avatar,
                    }
                },
                "text": text,
                "replyMessage": {}
            }]
        }
    } else {
        var data = {
            "type": "quote",
            "format": "png",
            "backgroundColor": "#FFFFFF",
            "width": 512,
            "height": 768,
            "scale": 2,
            "messages": [{
                "entities": [],
                "media": {
                    "url": media
                },
                "avatar": true,
                "from": {
                    "id": 1,
                    "name": name,
                    "photo": {
                        "url": avatar,
                    }
                },
                "text": text,
                "replyMessage": {}
            }]
        }
    }

    try {
        const result = await axios.post("https://quote.btch.bz/generate", data);
        const buffer = Buffer.from(result.data.result.image, 'base64');
        res.set({ 'Content-Type': 'image/png' });
        res.send(buffer);
    } catch (error) {
        console.error("Error fetching image:", error);
        res.status(500).send("Error fetching image");
    }
});

export default router;

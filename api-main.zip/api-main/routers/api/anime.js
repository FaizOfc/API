import { quotesanime } from "../../scapers/quotesanime.js";
import { addReq } from "../../src/add-totalreq.js";
import { Router } from "express";

const router = Router();

router.get('/api/anime/quotes', addReq, async(req, res) => {
    await quotesanime().then(data => {
        res.json({ creator, status: true, result: data[0]})
    }).catch(e => {
        res.status(404).json({ creator, status: false, message: 'Internal Error'})
    })
})

router.get('/api/anime/character', addReq, async(req, res) => {
    const name = req.query.name;
    
    /* await character(name).then(result => {
        res.json({ creator, status: true, result });
    }).catch(e => {
        res.status(404).json({ creator, status: false, message: 'Internal Error'})
        console.error(e);
    })
    */
})
export default router;
import axios from "axios";
import { addReq } from "../../src/add-totalreq.js"
import { Router } from "express"; 
import { removeBgGET } from "../../scapers/remove-bg.js";

const router = Router();

router.get('/api/tools/shortlink', addReq, async (req, res) => {
    const url = req.query.url;

    try {
        const { data } = await axios.post("https://cdn.xyzen.tech/api/shorturl", {
            longURL: url
        });
        res.json({ creator, status: true, result: data});
    } catch (error) {
        console.error("Error while shortening URL:", error);
        res.status(500).send("Error occurred while shortening URL");
    }
});

router.get('/api/tools/removebg', addReq, async (req, res) => {
    const url = req.query.url;

    if (!url) return res.status(400).json("URL is required");
    await removeBgGET(url).then((result) => {
        const buffer = Buffer.from(result, 'base64');
        res.json({ status: true, result: buffer.toString('base64') });
    }).catch((error) => {
        console.error("Error while removing background:", error);
        res.status(500).send("Error occurred while removing background");
    })
})
export default router;

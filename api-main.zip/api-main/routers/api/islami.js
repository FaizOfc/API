import { pickRandom } from "../../lib/function.js";
import { surah } from "../../scapers/detail-surah.js";
import { listsurah } from "../../scapers/list-surah.js";
import { addReq } from "../../src/add-totalreq.js"
import { Router } from "express";
import fs from "fs";

const router = Router();

router.get('/api/islami/listsurah', addReq, async (req, res) => {
    await listsurah(result => {
        res.json({ creator, status: true, result })
    }).catch(e => {
        res.status(500).json({ creator, status: false, message: '[!] The server encountered an internal error and was unable to complete your request. Either the server is overloaded or there is an error in the application.'})
    })
})

router.get('/api/islami/detailsurah', addReq, async (req, res) => {
    const detailSurah = req.query.surah;

    if (!detailSurah) return res.status(404).json({ creator, status: false, message: 'Please provide the surah parameter.' })

    await surah(hasil => {
        res.json({ creator, status: true, result: hasil })
    }).catch(e => {
        res.status(500).json({ creator, status: false, message: '[!] The server encountered an internal error and was unable to complete your request. Either the server is overloaded or there is an error in the application.'})
    })
})

router.get('/api/islami/asmaulhusna', addReq, async(req, res) => {
    const data = await JSON.parse(fs.readFileSync('database/AsmaulHusna.json'))
    const pick = await pickRandom(data.result);
    res.json({
        creator,
        status: true,
        result: pick
    })
})
export default router;
import { Router } from "express";
import { tiktokdl } from "../../scapers/tiktok.js"
import { igdl } from "../../scapers/instagram.js"
import { addReq } from "../../src/add-totalreq.js"

const router = Router();

router.use('/api/downloader/tiktok', addReq, async(req, res) => {
    const url = req.query.url;

    if (!url) return res.json({ creator, status: false, message: 'Please provide the Url parameter.'})

    await tiktokdl(url)
    .then(result => {
        res.json({ creator, status: true, caption: result.caption, video: result.server1.url })
    })
    .catch(e => {
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    })
})

router.use('/api/downloader/instagram', addReq, async(req, res) => {
    const url = req.query.url;

    if (!url) return res.json({ creator, status: false, message: 'Please provide the Url parameter.'});
    
    await igdl(url)
    .then(result => {
        res.json({ creator, status: true, result })
    })
    .catch(e => {
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    })
})

export default router
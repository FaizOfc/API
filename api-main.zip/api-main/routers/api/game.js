import { Router } from "express"; 
import { addReq } from "../../src/add-totalreq.js"
import { pickRandom } from "../../lib/fetch.js"
import { readFileSync } from "fs";

const router = Router();

router.get('/api/game/asahotak', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/asahotak.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/caklontong', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/caklontong.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/family100', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/family100.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/kuisrandom', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/kuis.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/siapakahaku', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/siapakahaku.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/susunkata', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/susunkata.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/tebakanime', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/tebakanime.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/tebakbendera', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/tebakbendera.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/tebakgambar', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/tebakgambar.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/tebakkabupaten', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/tebakkabupaten.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/tebakkalimat', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/tebakkalimat.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/tebakkata', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/tebakkata.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/tebakkimia', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/tebakkimia.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/tebaklagu', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/tebaklagu.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});

router.get('/api/game/tebaklirik', addReq, async (req, res) => {
    try {
        const rawData = readFileSync('database/game/tebaklirik.json');
        const data = JSON.parse(rawData);
        const result = await pickRandom(data);
        res.json({ creator, status: true, result });
    } catch (error) {
        console.error(error);
        res.status(500).json({ creator, status: false, message: 'Internal server error' });
    }
});
export default router;

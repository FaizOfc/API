import ytdl from 'ytdl-core';

export async function ytmp4(url) {
    try {
        if (!ytdl.validateURL(url)) {
            throw new Error('URL YouTube tidak valid.');
        }

        const info = await ytdl.getInfo(url);

        const result = {
            title: info.videoDetails.title,
            description: info.videoDetails.description,
            video: info.formats[0].url
        };

        return result
    } catch (err) {
        console.error(err.message);
    }
}
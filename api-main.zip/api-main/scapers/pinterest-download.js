import axios from "axios";
import cheerio from "cheerio";

export async function pindl(url) {
    return new Promise(async (resolve, reject) => {
        try {
            const params = new URLSearchParams();
            params.append("url", url);

            const response = await axios.post('https://pinterestvideodownloader.com/', params);
            const htmlContent = response.data;

            const $ = cheerio.load(htmlContent);

            $("table > tbody > tr").each(function(index, element) {
                const url = $(element).find("td").eq(0).find("a").attr("href");

                if (url && url !== "") {
                    resolve(url);
                }
            });

        } catch (error) {
            reject(error);
        }
    });
};
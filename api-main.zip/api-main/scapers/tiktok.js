import t from "axios";
import i from "form-data";
import a from "cheerio";
export async function tiktokdl(d) {
    let e = {},
        r = new i;
    r.append("q", d), r.append("lang", "id");
    try {
        let {
            data: o
        } = await t("https://savetik.co/api/ajaxSearch", {
            method: "post",
            data: r,
            headers: {
                "content-type": "application/x-www-form-urlencoded",
                "User-Agent": "PostmanRuntime/7.32.2"
            }
        }), n = a.load(o.data);
        return e.status = !0, e.caption = n("div.video-data > div > .tik-left > div > .content > div > h3").text(), e.server1 = {
            quality: "MEDIUM",
            url: n("div.video-data > div > .tik-right > div > p:nth-child(1) > a").attr("href")
        }, e.serverHD = {
            quality: n("div.video-data > div > .tik-right > div > p:nth-child(3) > a").text().split("MP4 ")[1],
            url: n("div.video-data > div > .tik-right > div > p:nth-child(3) > a").attr("href")
        }, e.audio = n("div.video-data > div > .tik-right > div > p:nth-child(4) > a").attr("href"), e
    } catch (v) {
        return e.status = !1, e.message = "Gatau kenapa", console.log(e), e
    }
}
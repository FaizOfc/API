import Replicate from "replicate";

const replicate = new Replicate({
  auth: "r8_NHlUr8iD4j0Ah03RWAWtyAFVLweSG8T3gZD34"
});

export async function remini(url) {
  var res = await replicate.run("jingyunliang/swinir:660d922d33153019e8c263a3bba265de882e7f4f70396546b6c9c8f9d47a021a", {
    input: {
      jpeg: 40,
      image: url,
      noise: 15,
      task_type: "Real-World Image Super-Resolution-Medium"
    }
  }).catch(async () => {
    var res = await replicate.run("mv-lab/swin2sr:a01b0512004918ca55d02e554914a9eca63909fa83a29ff0f115c78a7045574f",{
        input: {
          task: "real_sr",
          image: url
        }
      });
      return res
  })
  return res
}
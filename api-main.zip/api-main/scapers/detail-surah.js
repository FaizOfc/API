import axios from "axios";
import cheerio from "cheerio";

export async function surah(query) {
    return new Promise((resolve, reject) => {
        axios.get(`https://litequran.net/${query}`)
            .then(({
                data
            }) => {
                const $ = cheerio.load(data);
                const hasil = [];

                $('article > ol.surah').each(function(index, element) {
                    const result = {
                        arab: $(element).find('> li > p.arabic').text(),
                        latin: $(element).find('> li > p.translate').text(),
                        ind: $(element).find('> li > p.meaning').text()
                    };

                    result.arab = result.arab.split('.').join('\n');
                    result.latin = result.latin.split('.').join('\n');
                    result.ind = result.ind.split('.').join('\n');

                    hasil.push(result);
                });

                resolve(hasil);
            })
            .catch(reject);
    });
}
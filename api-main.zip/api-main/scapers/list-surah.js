import axios from "axios";
import cheerio from "cheerio";

export async function listsurah() {
    return new Promise((resolve, reject) => {
        axios.get('https://litequran.net/')
            .then(({
                data
            }) => {
                const $ = cheerio.load(data);
                const result = [];

                $('ol.list a').each((index, element) => {
                    const chapterName = $(element).text().replace(/\s/g, '-');
                    result.push(chapterName);
                });

                resolve(result);
            })
            .catch(reject);
    });
}
import axios from "axios";

export async function removeBgGET(url) {
  try {
    const response = await axios.request({
        method: "GET",
        url: "https://remove-background-of-any-image-object.p.rapidapi.com/rembg",
        params: { url },
        headers: {
            'X-RapidAPI-Key': '6a9259358bmshba34d148ba324e8p12ca27jsne16ce200ce10',
            'X-RapidAPI-Host': 'remove-background-of-any-image-object.p.rapidapi.com'
        }
    });
    return response.data;
  } catch (error) {
    console.error(error);
  }
}
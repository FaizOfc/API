document.addEventListener("DOMContentLoaded", function() {
    var second = document.getElementById("mobileMenu");
    var header = document.getElementById("mainHeader");
    var mobileMenuIcon = document.getElementById("mobileMenuIcon");
    var mobileMenu = document.getElementById("mobileMenu");

    if (header && second && mobileMenuIcon && mobileMenu) {
        var sticky = header.offsetTop;
        window.onscroll = function() {
            if (window.pageYOffset > sticky) {
                header.classList.add("sticky-nav");
                second.classList.add("sticky-nav");
            } else {
                header.classList.remove("sticky-nav");
                second.classList.remove("sticky-nav");
            }
        };
        mobileMenuIcon.addEventListener("click", function(event) {
            history.replaceState(null, document.title, window.location.pathname);
            event.preventDefault();
            mobileMenu.classList.toggle('!top-24');
            mobileMenu.hidden = !mobileMenu.hidden;
        });
    }

    var buttonMenu = document.getElementById("buttonSub");
    var idMenu = document.getElementById('submenu');
    if (buttonMenu && idMenu) {
        idMenu.addEventListener('click', function() {
            buttonMenu.classList.toggle('opacity-0');
            buttonMenu.classList.toggle('opacity-100');
        });
    }

    var menuSidebar = document.getElementById('menuSidebar');
    var sidebar = document.getElementById('sideBar');
    if (menuSidebar && sidebar) {
        menuSidebar.addEventListener('click', function(event) {
            event.stopPropagation();
            sidebar.classList.toggle('!visible');
            sidebar.classList.toggle('!opacity-100');
            sidebar.classList.toggle('!w-72');
            document.addEventListener('click', closeSidebarOnClickOutside);
        });
    }

    function closeSidebarOnClickOutside(event) {
        var sidebar = document.getElementById('sideBar');
        var menuSidebar = document.getElementById('menuSidebar');
        if (sidebar && !sidebar.contains(event.target) && menuSidebar !== event.target) {
            sidebar.classList.remove('!visible');
            sidebar.classList.remove('!opacity-100');
            sidebar.classList.remove('!w-72');
            document.removeEventListener('click', closeSidebarOnClickOutside);
        }
    }

    window.addEventListener('scroll', function() {
        var targetList = document.querySelectorAll('.list-none li');
        targetList.forEach(function(listItem) {
            var targetID = listItem.getAttribute('data-scroll-target');
            var targetElement = document.getElementById(targetID);
            var scrollClass = listItem.getAttribute('data-scroll-class');
            if (targetElement) {
                var scrollPosition = window.scrollY;
                var targetPosition = targetElement.getBoundingClientRect().top;
                var targetHeight = targetElement.offsetHeight;
                if (scrollPosition > targetPosition && scrollPosition < targetPosition + targetHeight) {
                    listItem.classList.add(scrollClass);
                } else {
                    listItem.classList.remove(scrollClass);
                }
            }
        });
    });

    const checkboxInput = document.getElementById("checkbox-container");
    const htmlElement = document.querySelector("html");

    checkboxInput.addEventListener("click", function() {
        // Cek apakah input checkbox saat ini dicentang atau tidak
        if (this.checked) {
            // Jika dicentang, tambahkan kelas "light" dan hapus kelas "dark" dari elemen HTML
            htmlElement.classList.remove("dark");
            htmlElement.classList.add("light");
            // Juga ubah nilai color-scheme menjadi "light"
            htmlElement.style.colorScheme = "light";
        } else {
            // Jika tidak dicentang, tambahkan kelas "dark" dan hapus kelas "light" dari elemen HTML
            htmlElement.classList.remove("light");
            htmlElement.classList.add("dark");
            // Juga ubah nilai color-scheme menjadi "dark"
            htmlElement.style.colorScheme = "dark";
        }
    });
   
});
